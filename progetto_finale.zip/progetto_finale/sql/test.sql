SELECT * FROM articles
